# AI CRM Flutter Full Skeleton

This project is a lightweight skeleton demonstrating:
- Provider for state management (AuthStore, LeadsStore)
- ApiService as a simple network layer (http package)
- Routing and basic pages (Login, Home, Leads, Lead Detail, Quote)

How to use:
1. unzip
2. run `flutter pub get`
3. open in Android Studio or VS Code
4. run `flutter run` (or build apk)

Notes:
- ApiService.baseUrl is set to a placeholder. Replace with your backend endpoints.
- This skeleton includes minimal error handling for clarity.
