import 'package:flutter/material.dart';
import '../services/api_service.dart';

class AuthStore extends ChangeNotifier {
  final ApiService api;
  String? _token;
  bool get isLoggedIn => _token != null;
  AuthStore(this.api);

  Future<void> login(String phone, String password) async {
    final resp = await api.login(phone, password);
    // Expecting { token: '...' }
    _token = resp['token'] as String?;
    api.token = _token;
    notifyListeners();
  }

  void logout() {
    _token = null;
    api.token = null;
    notifyListeners();
  }
}
