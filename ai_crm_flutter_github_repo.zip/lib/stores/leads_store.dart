import 'package:flutter/material.dart';
import '../services/api_service.dart';

class LeadsStore extends ChangeNotifier {
  final ApiService api;
  List<Map<String,dynamic>> leads = [];
  bool loading = false;
  LeadsStore(this.api);

  Future<void> fetchLeads({String? q}) async {
    loading = true;
    notifyListeners();
    try {
      final data = await api.getLeads(q: q);
      leads = data.map((e) => Map<String,dynamic>.from(e)).toList();
    } catch (e) {
      // handle error in UI
    } finally {
      loading = false;
      notifyListeners();
    }
  }
}
