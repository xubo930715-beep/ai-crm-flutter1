import 'package:flutter/material.dart';

// Add reusable widgets here, e.g., EmptyState, LoadingCard, etc.

class EmptyState extends StatelessWidget {
  final String message;
  const EmptyState({super.key, this.message = '暂无数据'});
  @override
  Widget build(BuildContext context) => Center(child: Text(message));
}
