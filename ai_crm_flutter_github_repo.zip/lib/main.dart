import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'stores/auth_store.dart';
import 'stores/leads_store.dart';
import 'pages/login_page.dart';
import 'pages/home_page.dart';
import 'services/api_service.dart';

void main() {
  final api = ApiService(baseUrl: 'https://api.yourdomain.com/v1'); // replace with real
  runApp(
    MultiProvider(
      providers: [
        Provider<ApiService>.value(value: api),
        ChangeNotifierProvider(create: (_) => AuthStore(api)),
        ChangeNotifierProvider(create: (_) => LeadsStore(api)),
      ],
      child: const AiCrmApp(),
    ),
  );
}

class AiCrmApp extends StatelessWidget {
  const AiCrmApp({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthStore>();
    return MaterialApp(
      title: 'AI CRM',
      theme: ThemeData(primarySwatch: Colors.teal),
      initialRoute: auth.isLoggedIn ? '/home' : '/login',
      routes: {
        '/login': (_) => const LoginPage(),
        '/home': (_) => const HomePage(),
      },
    );
  }
}
