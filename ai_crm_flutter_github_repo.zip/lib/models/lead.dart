class Lead {
  final String id;
  final String name;
  final String contact;
  final String type;
  final String city;
  final int aiScore;
  final String lastAction;

  Lead({required this.id, required this.name, required this.contact, required this.type, required this.city, required this.aiScore, required this.lastAction});

  factory Lead.fromJson(Map<String,dynamic> json) => Lead(
    id: json['id']?.toString() ?? '',
    name: json['name'] ?? '',
    contact: json['contact'] ?? '',
    type: json['type'] ?? '',
    city: json['city'] ?? '',
    aiScore: (json['aiScore'] ?? 0) as int,
    lastAction: json['lastAction'] ?? '',
  );
}
