import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  final String baseUrl;
  String? token;
  ApiService({required this.baseUrl});

  Map<String,String> _headers() {
    final h = {'Content-Type': 'application/json'};
    if (token != null) h['Authorization'] = 'Bearer \$token';
    return h;
  }

  Future<Map<String,dynamic>> login(String phone, String password) async {
    // Replace with real endpoint
    final res = await http.post(Uri.parse('\$baseUrl/auth/login'),
        headers: _headers(),
        body: jsonEncode({'phone': phone, 'password': password}));
    if (res.statusCode == 200) {
      return jsonDecode(res.body);
    }
    throw Exception('Login failed: \${res.statusCode}');
  }

  Future<List<dynamic>> getLeads({String? q}) async {
    final uri = Uri.parse('\$baseUrl/leads').replace(queryParameters: q!=null?{'q':q}:null);
    final res = await http.get(uri, headers: _headers());
    if (res.statusCode == 200) {
      return jsonDecode(res.body) as List<dynamic>;
    }
    throw Exception('getLeads failed: \${res.statusCode}');
  }

  Future<Map<String,dynamic>> generateQuote(Map<String,dynamic> payload) async {
    final res = await http.post(Uri.parse('\$baseUrl/quotes/generate'),
      headers: _headers(),
      body: jsonEncode(payload));
    if (res.statusCode == 200) {
      return jsonDecode(res.body);
    }
    throw Exception('generateQuote failed: \${res.statusCode}');
  }
}
