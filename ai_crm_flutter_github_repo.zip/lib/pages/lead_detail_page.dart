import 'package:flutter/material.dart';
import '../models/lead.dart';

class LeadDetailPage extends StatelessWidget {
  final Lead lead;
  const LeadDetailPage({super.key, required this.lead});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(lead.name)),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            CircleAvatar(child: Text(lead.name.isNotEmpty ? lead.name[0] : '?')),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(lead.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), Text('联系人: \${lead.contact}')]))
          ]),
          const SizedBox(height: 12),
          Chip(label: Text('AI 成交概率 \${lead.aiScore}%')),
          const SizedBox(height: 12),
          const Text('AI 客户画像', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          Text('该店为 \${lead.type}，近期有查看报价行为，建议电话跟进并提供高峰时段机型方案。'),
        ]),
      ),
    );
  }
}
