import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/api_service.dart';

class QuotePage extends StatefulWidget {
  const QuotePage({super.key});
  @override
  State<QuotePage> createState() => _QuotePageState();
}

class _QuotePageState extends State<QuotePage> {
  final _type = TextEditingController();
  final _flow = TextEditingController();
  final _area = TextEditingController();
  final _city = TextEditingController();
  String _result = '';
  bool _loading = false;

  Future<void> _generate() async {
    setState(() { _loading = true; _result = ''; });
    final api = context.read<ApiService>();
    try {
      final payload = {'type': _type.text, 'flow': int.tryParse(_flow.text) ?? 0, 'area': double.tryParse(_area.text) ?? 0.0, 'city': _city.text};
      // In absence of real backend, do a local sample generation
      if (api.baseUrl.contains('yourdomain')) {
        final rec = payload['flow'] as int > 200 ? 'X3 高产能' : 'X1 标准型';
        final price = (payload['flow'] as int > 200) ? '￥980/月' : '￥680/月';
        setState(() { _result = '推荐机型：\$rec\n月租：\$price\n理由：适配\${payload['type']}'; });
      } else {
        final resp = await api.generateQuote(payload);
        setState(() { _result = resp.toString(); });
      }
    } catch (e) {
      setState(() { _result = '生成失败: ' + e.toString(); });
    } finally {
      setState(() { _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(12),
      child: Column(children: [
        TextField(controller: _type, decoration: const InputDecoration(labelText: '餐厅类型')),
        const SizedBox(height: 8),
        TextField(controller: _flow, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: '日均客流')),
        const SizedBox(height: 8),
        TextField(controller: _area, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: '厨房面积(㎡)')),
        const SizedBox(height: 8),
        TextField(controller: _city, decoration: const InputDecoration(labelText: '城市')),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: ElevatedButton(onPressed: _loading?null:_generate, child: _loading?const CircularProgressIndicator(color: Colors.white):const Text('生成报价'))),
        const SizedBox(height: 12),
        Container(width: double.infinity, padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8), boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4)]), child: Text(_result.isEmpty ? '等待生成...' : _result))
      ]),
    );
  }
}
