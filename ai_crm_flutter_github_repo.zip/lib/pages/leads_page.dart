import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../stores/leads_store.dart';
import '../models/lead.dart';
import 'lead_detail_page.dart';

class LeadsPage extends StatefulWidget {
  const LeadsPage({super.key});
  @override
  State<LeadsPage> createState() => _LeadsPageState();
}

class _LeadsPageState extends State<LeadsPage> {
  String? _q;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<LeadsStore>().fetchLeads());
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LeadsStore>();
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: '搜索店名/电话'),
            onChanged: (v) => _q = v,
            onSubmitted: (_) => context.read<LeadsStore>().fetchLeads(q: _q),
          ),
        ),
        Expanded(
          child: store.loading
            ? const Center(child: CircularProgressIndicator())
            : ListView.builder(
                itemCount: store.leads.length,
                itemBuilder: (_, i) {
                  final map = store.leads[i];
                  final lead = Lead.fromJson(map);
                  return ListTile(
                    title: Text(lead.name),
                    subtitle: Text('${lead.type} · ${lead.city}'),
                    trailing: Text('${lead.aiScore}%'),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => LeadDetailPage(lead: lead))),
                  );
                },
              ),
        )
      ],
    );
  }
}
