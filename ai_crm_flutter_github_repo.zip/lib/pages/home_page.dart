import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../stores/auth_store.dart';
import 'leads_page.dart';
import 'quote_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _index = 0;
  final pages = [const LeadsPage(), const QuotePage(), Center(child: Text('客户')), Center(child: Text('我的'))];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI CRM'),
        actions: [
          IconButton(onPressed: () => context.read<AuthStore>().logout(), icon: const Icon(Icons.logout))
        ],
      ),
      body: pages[_index],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.leaderboard), label: '线索'),
          BottomNavigationBarItem(icon: Icon(Icons.request_quote), label: '报价'),
          BottomNavigationBarItem(icon: Icon(Icons.people), label: '客户'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: '我的'),
        ],
      ),
    );
  }
}
